package com.abc.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.abc.model.BillDetail;
import com.abc.model.CustomerDetail;
import com.abc.model.Product;
import com.abc.model.UserDetail;

public class Payment implements IPayment{
	
	// use the farmework to inject the bject insted of hardcode
	
	PaymentHelper paymentHelper =new  PaymentHelper();

	@Override
	public int getPayAmount(int billdId) throws Exception {
		int payAmount =0;
		BillDetail billdetail=paymentHelper.getBillDetail(billdId);
		//take the user id from the session
		int userId=1;
		UserDetail   userDetail=paymentHelper.getUserDetail(userId ) ;
		CustomerDetail custDetail=getCustomerDetail(userId) ;
		List<Product> lstOfProduct= billdetail.getLstOfProduct() ;
		
		
		if(lstOfProduct !=null) {
				for(Product p : lstOfProduct){
					payAmount=payAmount + p.getProductCost();
				}	
				
				if(userDetail.isEmployee()){
					
					payAmount=(payAmount*30)/100;
				}
				else if(userDetail.isAffilate()){
					payAmount=(payAmount*10)/100;
				
				}else if(checkTwoYearOld(custDetail.getStartDate())){
					
					payAmount=(payAmount*5)/100;
				}
					
		
		
		} else {
			throw new Exception(" No product is bought") ;
		}
		
		return payAmount;
	}
	
	 private boolean checkTwoYearOld(Date startDate){
		 Calendar calendar  = Calendar.getInstance();
		 calendar.add(Calendar.YEAR, -2);
		 Date d = calendar.getTime();
		 
		 return d.after(startDate) ;
		 
	 }

	@Override
	public Product getProductDetail(int productId) {
	
		return null;
	}

	@Override
	public CustomerDetail getCustomerDetail(int custId) {
		
		return null;
	}

}
