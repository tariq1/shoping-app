package com.abc.service;

import java.util.List;

import com.abc.model.CustomerDetail;
import com.abc.model.Product;

public interface IPayment {
	
	int getPayAmount(int billdId) throws Exception ;
	Product getProductDetail(int productId);
	CustomerDetail getCustomerDetail(int custId) ;
	
	
}
